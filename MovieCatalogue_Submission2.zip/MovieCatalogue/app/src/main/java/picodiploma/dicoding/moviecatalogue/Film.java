package picodiploma.dicoding.moviecatalogue;

import android.os.Parcel;
import android.os.Parcelable;


public class Film implements Parcelable {

    public static final Creator<Film> CREATOR = new Creator<Film>() {
        @Override
        public Film createFromParcel(Parcel source) {
            return new Film(source);
        }

        @Override
        public Film[] newArray(int size) {
            return new Film[size];
        }
    };
    private int foto;
    private String description;
    private String title;

    public Film() {
    }

    protected Film(Parcel in) {
        this.foto = in.readInt();
        this.description = in.readString();
        this.title = in.readString();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.foto);
        dest.writeString(this.description);
        dest.writeString(this.title);
    }
}
