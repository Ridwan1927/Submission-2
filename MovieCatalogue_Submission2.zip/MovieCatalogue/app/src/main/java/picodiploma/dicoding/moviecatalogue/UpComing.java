package picodiploma.dicoding.moviecatalogue;


import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class UpComing extends Fragment {
    private String[] dataName;
    private String[] dataDescription;
    private TypedArray dataPhoto;
    private AdapterTab adapter;
    private ListView listView;
    private AdtFilm adtFilm;
    private View view;
    private ArrayList<Film> films = new ArrayList<>();


    public UpComing() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_up_coming, container, false);
        prepare();
        addItem();
        RecyclerView recyclerView = view.findViewById(R.id.upComing);
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        recyclerView.setHasFixedSize(true);
        adtFilm = new AdtFilm(getContext(), films);
        recyclerView.setAdapter(adtFilm);
        return view;
    }
    private void addItem() {

        for (int i = 0; i < dataName.length; i++) {
            Film film = new Film();
            film.setFoto(dataPhoto.getResourceId(i, -1));
            film.setTitle(dataName[i]);
            film.setDescription(dataDescription[i]);
            films.add(film);
        }
    }

    private void prepare() {
        dataName = getResources().getStringArray(R.array.data_name_up);
        dataDescription = getResources().getStringArray(R.array.data_deskripsi_up);
        dataPhoto = getResources().obtainTypedArray(R.array.data_image_up);
    }
}
