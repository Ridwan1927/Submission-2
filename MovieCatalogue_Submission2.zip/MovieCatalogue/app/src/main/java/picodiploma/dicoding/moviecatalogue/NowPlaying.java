package picodiploma.dicoding.moviecatalogue;


import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class NowPlaying extends Fragment {
    private String[] dataName;
    private String[] dataDescription;
    private TypedArray dataPhoto;
    //private AdapterTab adapter;
    //private ListView listView;
    private AdtFilm adtFilm;
    private View view;
    private ArrayList<Film> movies = new ArrayList<>();

    public NowPlaying() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_now_playing, container, false);
        prepare();
        addItem();
        RecyclerView recyclerView = view.findViewById(R.id.nowPlaying);
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        Log.d("listCount", movies.size() + "");
        adtFilm = new AdtFilm(getContext(), movies);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adtFilm);
        return view;
    }

     private void addItem() {

         for (int i = 0; i < dataName.length; i++) {
           Film film = new Film();
           film.setFoto(dataPhoto.getResourceId(i, -1));
           film.setTitle(dataName[i]);
           film.setDescription(dataDescription[i]);
        movies.add(film);
        }
       // adapter.setMovies(movies);
         }

        private void prepare() {
          dataName = getResources().getStringArray(R.array.data_name);
         dataDescription = getResources().getStringArray(R.array.data_deskripsi);
        dataPhoto = getResources().obtainTypedArray(R.array.data_image);
         }

}
