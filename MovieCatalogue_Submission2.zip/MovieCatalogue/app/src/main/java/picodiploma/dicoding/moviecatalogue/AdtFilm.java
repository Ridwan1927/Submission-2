package picodiploma.dicoding.moviecatalogue;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;


public class AdtFilm extends RecyclerView.Adapter<AdtFilm.MyView> {
    private ArrayList<Film> listFilm;
    private Context context;


    public AdtFilm(Context context, ArrayList<Film> film) {
        this.context = context;
        this.listFilm = film;
    }


    @NonNull
    @Override
    public MyView onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.movie_list, viewGroup, false);
        return new MyView(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyView myView, final int i) {
        myView.txtJudulSub2.setText(listFilm.get(i).getTitle());
        myView.txtDescSub2.setText(listFilm.get(i).getDescription());
        myView.imgSub2.setImageResource(listFilm.get(i).getFoto());

        myView.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, detail_film.class);
                Film film = listFilm.get(i);
                intent.putExtra("items", film);
                v.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listFilm.size();
    }

    class MyView extends RecyclerView.ViewHolder {
        TextView txtJudulSub2, txtDescSub2;
        ImageView imgSub2;
        
        private RelativeLayout relativeLayout;
        public MyView(View view) {
            super(view);
            imgSub2 = itemView.findViewById(R.id.img_film);
            txtJudulSub2 = itemView.findViewById(R.id.tv_title);
            txtDescSub2 = itemView.findViewById(R.id.tv_detail);
            relativeLayout= itemView.findViewById(R.id.RLitems);


        }

    }


}
