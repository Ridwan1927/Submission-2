package picodiploma.dicoding.moviecatalogue;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.provider.Settings;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    private TabLayout tabL;
    private AdapterTab nAdapter;
    private ViewPager vPage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTbLay();

    }

    private void setTbLay() {
    tabL = findViewById(R.id.tb_layout);
    vPage = findViewById(R.id.vp_layout);
    nAdapter = new AdapterTab(getSupportFragmentManager());
    nAdapter.TambahFragment(new NowPlaying(),getString(R.string.now));
    nAdapter.TambahFragment(new UpComing(),getString(R.string.up));
    vPage.setAdapter(nAdapter);
    tabL.setupWithViewPager(vPage);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);
    tabL.setTabTextColors(ColorStateList.valueOf(getResources().getColor(R.color.colorAccent)));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.Eng:
            Intent myIntent = new Intent(Settings.ACTION_LOCALE_SETTINGS);
            startActivity(myIntent);
            break;
            case R.id.search_button:
            break;
            default:
        }
        return super.onOptionsItemSelected(item);
    }
}
