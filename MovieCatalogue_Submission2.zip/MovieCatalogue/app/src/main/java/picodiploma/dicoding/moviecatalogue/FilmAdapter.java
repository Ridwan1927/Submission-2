package picodiploma.dicoding.moviecatalogue;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class FilmAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<Film> movies;

    public FilmAdapter(Context context) {
        this.context = context;
        movies = new ArrayList<>();
    }

    public void setMovies(ArrayList<Film> movies) {
        this.movies = movies;
    }

    @Override
    public int getCount() {
        return movies.size();
    }

    @Override
    public Object getItem(int i) {
        return movies.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.movie_list, viewGroup, false);
        }
        Film film = (Film) getItem(i);
        TextView txtTitle = view.findViewById(R.id.tv_title);
        TextView txtDetail = view.findViewById(R.id.tv_detail);
        ImageView imgMovies = view.findViewById(R.id.img_film);
        txtTitle.setText(film.getTitle());
        txtDetail.setText(film.getDescription());
        imgMovies.setImageResource(film.getFoto());
        return view;
    }
}
